// GameObserver.java
package model;

public interface GameObserver {
    void update();
}
