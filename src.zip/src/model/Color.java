// Color.java
package model;

public enum Color {
    RED, BLUE;
}
